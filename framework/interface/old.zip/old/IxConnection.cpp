#include "IxConnection.h"

//------------------------------------------------------------------------------
IxConnection::IxConnection()
{  

}
