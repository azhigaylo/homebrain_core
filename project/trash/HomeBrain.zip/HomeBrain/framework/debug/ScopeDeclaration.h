#ifndef SCOPE_DECLARATION
#define SCOPE_DECLARATION

void ScopeRegistration();

#endif // SCOPE_DECLARATION
